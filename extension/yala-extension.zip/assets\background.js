const e=async()=>{await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0})};chrome.runtime.onInstalled.addListener(()=>{e()});chrome.runtime.onStartup.addListener(()=>{e()});
